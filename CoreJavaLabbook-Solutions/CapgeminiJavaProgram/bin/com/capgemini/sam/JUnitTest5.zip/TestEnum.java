package com.capgemini.sam;

public class TestEnum {
	public static void main(String arg[]) {
		
		System.out.println(UserStatus.ACTIVE);
	}
}
